function showAlert() {
    var myText = "Submitted Sucessfully!";
    alert (myText);
  }